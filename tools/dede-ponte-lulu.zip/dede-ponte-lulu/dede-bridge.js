/* Dedé · Ponte do Lulu — entrega a fila ao Dedé, pede para abrir o registro do card certo
   e avisa a extensão quando o designer registrou (ou fechou) para voltar ao Lulu. */
(() => {
  const keyOf = c => c.luluId || `${c.name}|${c.concluidoEm}`;
  const post = m => window.postMessage({ src: 'dede-ponte', ...m }, location.origin);
  const push = async abrir => {
    const { fila = [] } = await chrome.storage.local.get('fila');
    post({ type: 'hello' });
    if (fila.length) post({ type: 'fila', cards: fila });
    if (abrir) post({ type: 'abrir', key: abrir });
  };
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data || e.data.src !== 'dede-app') return;
    if (e.data.type === 'hello') return push();
    if (e.data.type === 'ack' && Array.isArray(e.data.keys)) {
      const done = new Set(e.data.keys);
      const { fila = [], hist = [] } = await chrome.storage.local.get(['fila', 'hist']);
      const now = new Date().toISOString();
      await chrome.storage.local.set({ fila: fila.filter(c => !done.has(keyOf(c))), hist: hist.map(h => done.has(h.key) && h.status === 'na fila' ? { ...h, status: 'no Dedé', em: now } : h) });
      return;
    }
    if (e.data.type === 'registrado' || e.data.type === 'fechou') {
      if (e.data.type === 'registrado') {
        const { hist = [] } = await chrome.storage.local.get('hist');
        await chrome.storage.local.set({ hist: hist.map(h => h.key === e.data.key ? { ...h, status: 'registrado', pts: e.data.pts } : h) });
      }
      try { chrome.runtime.sendMessage({ type: e.data.type, key: e.data.key, pts: e.data.pts, valor: e.data.valor, ja: e.data.ja }); } catch (err) {}
    }
  });
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'abrir' && m.key) push(m.key); });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.fila && (ch.fila.newValue || []).length) push(); });
  document.documentElement.dataset.dedePonte = '1';
  push(new URLSearchParams(location.search).get('lulu'));
})();
