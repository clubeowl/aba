/* Dedé · Ponte do Lulu — entrega a fila ao Dedé e limpa o que ele confirmou. */
(() => {
  const keyOf = c => c.luluId || `${c.name}|${c.concluidoEm}`;
  const push = async () => {
    const { fila = [] } = await chrome.storage.local.get('fila');
    window.postMessage({ src: 'dede-ponte', type: 'hello' }, location.origin);
    if (fila.length) window.postMessage({ src: 'dede-ponte', type: 'fila', cards: fila }, location.origin);
  };
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data || e.data.src !== 'dede-app') return;
    if (e.data.type === 'hello') return push();
    if (e.data.type === 'ack' && Array.isArray(e.data.keys)) {
      const done = new Set(e.data.keys);
      const { fila = [] } = await chrome.storage.local.get('fila');
      await chrome.storage.local.set({ fila: fila.filter(c => !done.has(keyOf(c))) });
    }
  });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.fila && (ch.fila.newValue || []).length) push(); });
  document.documentElement.dataset.dedePonte = '1';
  push();
})();
