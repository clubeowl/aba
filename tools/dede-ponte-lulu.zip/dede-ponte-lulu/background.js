/* Ponte do Lulu · fundo
   - número no ícone: cards esperando o Dedé
   - depois do OK no Lulu: abre o Dedé numa janelinha já no "Registrar card"
   - registrou ou fechou: fecha a janelinha e volta para o Lulu */
const DEDE = 'https://clubeowl.github.io/aba/';
const W = 1180, H = 860;

const badge = async () => {
  const { fila = [] } = await chrome.storage.local.get('fila');
  chrome.action.setBadgeText({ text: fila.length ? String(fila.length) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#F5A800' });
};

async function abrir(key, luluTab) {
  await chrome.storage.session.set({ lulu: luluTab ? { tabId: luluTab.id, winId: luluTab.windowId } : null });
  const { pop } = await chrome.storage.session.get('pop');
  if (pop) {
    try {
      const w = await chrome.windows.get(pop.winId, { populate: true });
      await chrome.windows.update(w.id, { focused: true });
      await chrome.tabs.sendMessage(w.tabs[0].id, { type: 'abrir', key });
      return;
    } catch (e) { await chrome.storage.session.remove('pop'); }
  }
  const opts = { url: DEDE + '?lulu=' + encodeURIComponent(key), type: 'popup', width: W, height: H, focused: true };
  if (luluTab) {
    try {
      const lw = await chrome.windows.get(luluTab.windowId);
      opts.width = Math.min(W, lw.width); opts.height = Math.min(H, lw.height);
      opts.left = Math.max(0, lw.left + Math.round((lw.width - opts.width) / 2));
      opts.top = Math.max(0, lw.top + Math.round((lw.height - opts.height) / 2));
    } catch (e) {}
  }
  let w = null;
  try { w = await chrome.windows.create(opts); }
  catch (e) { try { w = await chrome.windows.create({ url: opts.url, type: 'popup', focused: true }); } catch (e2) { w = null; } }
  if (!w) { const t = await chrome.tabs.create({ url: opts.url, active: true }); w = { id: t.windowId, tab: true }; }
  if (!w.tab) await chrome.storage.session.set({ pop: { winId: w.id } });
}

async function voltar(m, dedeTab) {
  const { pop, lulu } = await chrome.storage.session.get(['pop', 'lulu']);
  if (pop && dedeTab && dedeTab.windowId === pop.winId) { await chrome.storage.session.remove('pop'); chrome.windows.remove(pop.winId).catch(() => {}); }
  if (!lulu) return;
  chrome.windows.update(lulu.winId, { focused: true }).catch(() => {});
  chrome.tabs.update(lulu.tabId, { active: true }).catch(() => {});
  const text = m.type === 'registrado' ? `Registrado no Dedé · ${m.pts} pts (${m.valor})` : m.ja ? 'Esse card já estava no Dedé' : 'Ficou no Dedé para pontuar depois';
  chrome.tabs.sendMessage(lulu.tabId, { type: 'flash', text }).catch(() => {});
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m) return;
  if (m.type === 'badge') badge();
  if (m.type === 'abrir' && m.key) abrir(m.key, sender.tab);
  if (m.type === 'registrado' || m.type === 'fechou') voltar(m, sender.tab);
});
chrome.windows.onRemoved.addListener(async id => { const { pop } = await chrome.storage.session.get('pop'); if (pop && pop.winId === id) chrome.storage.session.remove('pop'); });
chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.fila) badge(); });
chrome.runtime.onStartup.addListener(badge);
chrome.runtime.onInstalled.addListener(badge);
