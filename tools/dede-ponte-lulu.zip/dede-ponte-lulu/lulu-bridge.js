/* Dedé · Ponte do Lulu — guarda os cards concluídos numa fila até o Dedé buscar. */
(() => {
  const keyOf = c => c.luluId || `${c.name}|${c.concluidoEm}`;
  const flash = text => {
    const el = document.createElement('div');
    el.textContent = text;
    el.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(10px);z-index:2147483647;background:#18181B;color:#fff;font:600 13px/1.3 Inter,system-ui,sans-serif;padding:11px 16px 11px 14px;border-radius:12px;box-shadow:0 18px 40px -16px rgba(0,0,0,.6),inset 0 0 0 1px rgba(255,255,255,.08);opacity:0;transition:all .35s cubic-bezier(.16,1,.3,1);display:flex;gap:8px;align-items:center;max-width:80vw';
    const dot = document.createElement('span'); dot.textContent = '✓';
    dot.style.cssText = 'width:20px;height:20px;border-radius:6px;background:#FDB913;color:#18181B;display:grid;place-items:center;font-weight:800;flex:none';
    el.prepend(dot); document.documentElement.appendChild(el);
    requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateX(-50%)'; });
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 3200);
  };
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'flash' && m.text) flash(m.text); });
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data || e.data.src !== 'dede-ponte-lulu' || e.data.type !== 'concluido') return;
    const card = e.data.card; if (!card || !card.name) return;
    const { fila = [] } = await chrome.storage.local.get('fila');
    const { hist = [] } = await chrome.storage.local.get('hist');
    if (!fila.some(x => keyOf(x) === keyOf(card))) fila.push(card);
    const h = [{ key: keyOf(card), name: card.name, at: card.concluidoEm, via: card.via || '', status: 'na fila' }, ...hist.filter(x => x.key !== keyOf(card))].slice(0, 40);
    await chrome.storage.local.set({ fila, hist: h });
    try { chrome.runtime.sendMessage({ type: 'badge' }); } catch (err) {}
    flash(`Abrindo o Dedé: ${card.name}`);
    try { chrome.runtime.sendMessage({ type: 'abrir', key: keyOf(card) }); } catch (err) {}
  });
})();
