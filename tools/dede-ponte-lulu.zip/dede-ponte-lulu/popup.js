const fmt = s => { const d = new Date(s); return isNaN(d) ? '' : `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const li = (name, tag, cls, when) => { const l = document.createElement('li'); const s = document.createElement('span'); s.textContent = name; s.title = name; const e = document.createElement('em'); e.className = cls; e.textContent = tag; const t = document.createElement('small'); t.textContent = when; t.style.color = '#A1A1AA'; l.append(s, t, e); return l; };
async function draw() {
  const { fila = [], hist = [] } = await chrome.storage.local.get(['fila', 'hist']);
  const F = document.getElementById('fila'), H = document.getElementById('hist'); F.textContent = ''; H.textContent = '';
  fila.forEach(c => F.append(li(c.name, 'na fila', 'q', fmt(c.concluidoEm))));
  if (!fila.length) F.innerHTML = '<div class="empty">nada pendente</div>';
  hist.slice(0, 12).forEach(h => H.append(li(h.name, h.status, h.status === 'na fila' ? 'q' : 'ok', fmt(h.at))));
  if (!hist.length) H.innerHTML = '<div class="empty">nenhum card capturado ainda. Conclua um card no Pipe Design do Lulu.</div>';
}
document.getElementById('clr').onclick = async () => { await chrome.storage.local.set({ hist: [] }); draw(); };
draw();
