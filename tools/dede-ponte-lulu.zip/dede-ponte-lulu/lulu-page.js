/* Dedé · Ponte do Lulu — roda na página do Lulu e só OBSERVA (não clica, não altera nada).
   Detecta que um card foi concluído por três caminhos, o que acontecer primeiro:
   1) clique no ✓ "Concluir" + "Confirmar Concluído" e o Lulu mostra "Solicitação encerrada" ou tira o card do board;
   2) o Lulu faz a chamada de conclusão (PATCH/POST/PUT) com o id daquele card e ela dá certo;
   3) depois de confirmar, se nada disso for visto em 8s, envia assim mesmo (no Dedé dá para descartar).
   Os dados do card vêm do próprio Lulu (lista do kanban e props do card). Logs: filtre o console por "Dedé ponte". */
(() => {
  if (window.__dedePonte) return; window.__dedePonte = '1.1';
  const log = (...a) => { try { console.info('%c[Dedé ponte]', 'color:#F5A800;font-weight:700', ...a); } catch (e) {} };
  const cache = new Map();          // id_discussao -> card
  const sent = new Set();
  let pend = null;

  const info = c => ({
    luluId: c.id_discussao || '', name: String((c.negocio && c.negocio.titulo) || '').replace(/\s+/g, ' ').trim(),
    assunto: c.assunto || '', lead: (c.negocio && c.negocio.nome_lead) || '', designer: c.responsavel_nome || '',
    squad: c.squad || '', tipo: c.tipo_servico || '',
  });
  const learn = (data, d = 0) => {
    if (!data || typeof data !== 'object' || d > 6) return;
    if (Array.isArray(data)) { data.forEach(x => learn(x, d + 1)); return; }
    if (data.id_discussao && data.negocio) { cache.set(data.id_discussao, info(data)); return; }
    for (const k in data) { const v = data[k]; if (v && typeof v === 'object') learn(v, d + 1); }
  };

  const fromReact = el => {
    const k = Object.keys(el).find(x => x.startsWith('__reactFiber'));
    let f = k && el[k];
    for (let i = 0; f && i < 40; i++, f = f.return) {
      const p = f.memoizedProps;
      const c = p && (p.card || p.solicitacao || p.item || p.request);
      if (c && typeof c === 'object' && (c.id_discussao || c.negocio)) return c;
    }
    return null;
  };
  const fromDom = btn => {
    let box = btn;
    for (let i = 0; i < 10 && box; i++) { box = box.parentElement; if (box && box.querySelector('button[title="Ampliar arte"], img') && box.querySelectorAll('p').length >= 2) break; }
    const ps = box ? [...box.querySelectorAll('p')].map(p => p.textContent.trim()) : [];
    const titulo = (ps[1] || '').split('•')[0].trim();
    const hit = [...cache.values()].find(c => c.name && titulo && c.name.startsWith(titulo.slice(0, 20)));
    return hit || { luluId: '', name: titulo, assunto: ps[0] || '' };
  };
  const pick = btn => { const c = fromReact(btn); return c ? info(c) : fromDom(btn); };

  const send = (card, how) => {
    if (!card || !card.name) { log('sem nome do card, nada enviado', card); return; }
    const key = card.luluId || card.name;
    if (sent.has(key)) return; sent.add(key);
    log('enviando ao Dedé (' + how + '):', card.name);
    window.postMessage({ src: 'dede-ponte-lulu', type: 'concluido', card: { ...card, concluidoEm: new Date().toISOString(), via: how } }, location.origin);
  };

  /* ---------- 2) observa as chamadas do Lulu (fetch e XHR) ---------- */
  const watch = (url, method, body, ok, json) => {
    try {
      url = String(url || ''); method = String(method || 'GET').toUpperCase();
      if (!/pipe-design|designer|solicita|discuss/i.test(url)) return;
      if (method === 'GET') { if (json) learn(json); return; }
      if (!ok) return;
      const txt = url + ' ' + (typeof body === 'string' ? body : '');
      if (pend && pend.confirmAt && pend.card.luluId && txt.includes(pend.card.luluId)) { const p = pend; pend = null; send(p.card, 'api'); return; }
      if (/conclu|encerr|finaliz/i.test(txt)) for (const [id, c] of cache) if (txt.includes(id)) { send(c, 'api'); return; }
    } catch (e) {}
  };
  const oFetch = window.fetch;
  window.fetch = async function (input, init) {
    const res = await oFetch.apply(this, arguments);
    try {
      const url = typeof input === 'string' ? input : input && input.url;
      const method = (init && init.method) || (input && input.method) || 'GET';
      const body = init && init.body;
      if (String(method).toUpperCase() === 'GET') { if (/pipe-design|designer/i.test(url)) res.clone().json().then(j => watch(url, method, body, res.ok, j)).catch(() => {}); }
      else watch(url, method, body, res.ok);
    } catch (e) {}
    return res;
  };
  const oOpen = XMLHttpRequest.prototype.open, oSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__dp = { m, u }; return oOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (body) {
    const x = this;
    try {
      x.addEventListener('load', () => {
        try {
          const d = x.__dp || {}, ok = x.status >= 200 && x.status < 300;
          let j = null;
          if (String(d.m).toUpperCase() === 'GET' && /pipe-design|designer/i.test(d.u)) { try { j = x.responseType === 'json' ? x.response : JSON.parse(x.responseText); } catch (e) {} }
          watch(d.u, d.m, body, ok, j);
        } catch (e) {}
      });
    } catch (e) {}
    return oSend.apply(this, arguments);
  };

  /* ---------- 1) e 3) os cliques ---------- */
  const nToast = () => (document.body.textContent.match(/solicita[cç][aã]o encerrada/gi) || []).length;
  document.addEventListener('click', e => {
    const b = e.target && e.target.closest && e.target.closest('button,[role="button"]');
    if (!b) return;
    const label = ((b.getAttribute('title') || '') + ' ' + (b.getAttribute('aria-label') || '')).trim();
    const txt = (b.textContent || '').replace(/\s+/g, ' ').trim();
    if (/^conclu(ir|do)$/i.test(label) || (/^conclu(ir|do)$/i.test(txt) && !/confirmar/i.test(txt))) {
      try { pend = { at: Date.now(), btn: b, card: pick(b) }; log('card marcado para concluir:', pend.card.name || '(sem nome)'); }
      catch (err) { pend = null; log('não consegui ler o card', err); }
      return;
    }
    if (pend && /confirmar\s+conclu/i.test(txt) && Date.now() - pend.at < 10 * 60 * 1000) {
      const p = pend; p.confirmAt = Date.now(); const n0 = nToast();
      log('confirmou conclusão de', p.card.name);
      const iv = setInterval(() => {
        if (pend !== p && sent.has(p.card.luluId || p.card.name)) { clearInterval(iv); return; }
        const seen = nToast() > n0 || !p.btn.isConnected;
        if (seen || Date.now() - p.confirmAt > 8000) { clearInterval(iv); if (pend === p) pend = null; send(p.card, seen ? 'tela' : 'tempo'); }
      }, 250);
      return;
    }
    if (pend && /^cancelar$/i.test(txt)) { log('cancelado'); pend = null; }
  }, true);
  log('ativa');
})();
