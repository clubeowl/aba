/* Dedé · Ponte do Lulu — roda na página do Lulu (só observa, não altera nada).
   1) Clique no ✓ "Concluir" de um card → guarda os dados daquele card.
   2) Clique em "Confirmar Concluído" → espera o Lulu confirmar ("Solicitação encerrada")
      e só então avisa a extensão, que entrega o card ao Dedé. */
(() => {
  if (window.__dedePonte) return; window.__dedePonte = true;
  let pend = null;

  const fromReact = el => {
    const k = Object.keys(el).find(x => x.startsWith('__reactFiber'));
    let f = k && el[k];
    for (let i = 0; f && i < 30; i++, f = f.return) {
      const c = f.memoizedProps && f.memoizedProps.card;
      if (c && typeof c === 'object' && (c.id_discussao || c.negocio)) return c;
    }
    return null;
  };
  const fromDom = btn => {
    let box = btn;
    for (let i = 0; i < 8 && box; i++) { box = box.parentElement; if (box && box.querySelector('button[title="Ampliar arte"]')) break; }
    const ps = box ? [...box.querySelectorAll('p')].map(p => p.textContent.trim()) : [];
    return { assunto: ps[0] || '', titulo: (ps[1] || '').split('•')[0].trim() };
  };
  const pick = btn => {
    const c = fromReact(btn);
    if (c) return {
      luluId: c.id_discussao || '', name: String((c.negocio && c.negocio.titulo) || '').replace(/\s+/g, ' ').trim(),
      assunto: c.assunto || '', lead: (c.negocio && c.negocio.nome_lead) || '', designer: c.responsavel_nome || '',
      squad: c.squad || '', tipo: c.tipo_servico || '',
    };
    const d = fromDom(btn); return { luluId: '', name: d.titulo, assunto: d.assunto };
  };

  const nToast = () => (document.body.textContent.match(/solicita[cç][aã]o encerrada/gi) || []).length;
  const confirmed = (p, t0, n0) => new Promise(res => {
    const iv = setInterval(() => {
      const toast = nToast() > n0;
      if (toast || !p.btn.isConnected) { clearInterval(iv); res(true); }
      else if (Date.now() - t0 > 12000) { clearInterval(iv); res(false); }
    }, 250);
  });

  document.addEventListener('click', e => {
    const b = e.target && e.target.closest && e.target.closest('button');
    if (!b) return;
    if (b.getAttribute('title') === 'Concluir') {
      try { pend = { at: Date.now(), btn: b, card: pick(b) }; } catch (err) { pend = null; }
      return;
    }
    if (pend && /confirmar\s+conclu/i.test(b.textContent || '') && Date.now() - pend.at < 5 * 60 * 1000) {
      const p = pend; pend = null;
      if (!p.card || !p.card.name) return;
      confirmed(p, Date.now(), nToast()).then(ok => {
        if (!ok) return;
        window.postMessage({ src: 'dede-ponte-lulu', type: 'concluido', card: { ...p.card, concluidoEm: new Date().toISOString() } }, location.origin);
      });
      return;
    }
    if (pend && /^\s*cancelar\s*$/i.test(b.textContent || '')) pend = null;
  }, true);
})();
